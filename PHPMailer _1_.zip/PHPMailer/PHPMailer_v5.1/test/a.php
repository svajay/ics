<form action="testemail.php">
<input type="email" name="email" id="email">
<input type="submit" name="send" value="send">


</form>